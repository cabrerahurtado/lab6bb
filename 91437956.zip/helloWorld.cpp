// minimal Hello World! program for testing Makefiles
// helloWorld.cpp for UCSB CS3
// Edited by: Jose Cabrera 
// minimal Hello World! Program 
#include <iostream>

int main() {
  std::cout << "Hello, World!" << std::endl;
  return 0;
}
